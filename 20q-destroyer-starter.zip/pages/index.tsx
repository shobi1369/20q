
import React from 'react';
import Page from '../app/page';

const Index: React.FC = () => <Page />;
export default Index;
